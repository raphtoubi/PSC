
from projet import detection_visage, scripts_skindetector, skin_detector
##from projet import traitement_signal
import cv2
import numpy as np
from projet import VideoTest



getFaceBox = detection_visage.getFaceBox
process = skin_detector.process
logging = skin_detector.logging
display = scripts_skindetector.display
##waveTransform2 = traitement_signal.waveTransform2


##initialisation

##pic d'interet toujours la : somme trois transformees en ondelettes differentes //matrices de matrices
"""data1 = []; ## premiere transformee en ondelettes
data2 = [];
data3 = [];"""

def detecteur_de_peau(video, debug=False):
    cam = cv2.VideoCapture(video)
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter('output1.avi', fourcc, 20.0, (640, 480))
    logging.info("press any key to exit")
    ret2=True

    while (ret2==True):
        ret2, img_col = cam.read()

        if ret2==True:
            ##DETECTION VISAGE RAPHAELLE
            bbox = getFaceBox(img_col)
            x = bbox[0]
            y = bbox[1]
            w = bbox[2]
            h = bbox[3]
            crop_img = img_col[y:y + h, x:x + w]

            ##DETECTION PEAU ROXANE
            img_msk = process(crop_img)
            imb_comb = cv2.bitwise_and(crop_img, crop_img, mask=img_msk) ##sortie visage
            display('img_skn', imb_comb) ##montre image

            ##ALEXIAN
            """pts = np.array([[10, 5], [20, 30], [70, 20], [50, 10]], np.int32)
            pts = pts.reshape((-1, 1, 2))
            b, g, r = cv2.split(img_col)
            data1.append(waveTransform2('db2', g));
            data2.append(waveTransform2('db4', g));
            data3.append(waveTransform2('db7', g));"""

            waitkey = cv2.waitKey(5)
            if waitkey != -1:
                break
    return
    cv2.destroyAllWindows()



def principal(videodepart):
    detecteur_de_peau(videodepart)
    VideoTest.main('output1.avi')


