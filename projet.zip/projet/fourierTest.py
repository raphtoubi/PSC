# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 18:27:45 2019

@author: Alexian
"""
"Cas 2D""""
import numpy as np;
import matplotlib.pyplot as plt;
from projet import traitement_signal
from projet import traitement_video
randMatrice=traitement_signal.randMatrice
periodMatrice=traitement_signal.periodMatrice


##dat1, dat2, dat3 = traitement_video.detecteur_de_peau(r'/Users/roxanefischer/Desktop/test.mov')


T=2;                "période spaciale de la matrice périodique"
n=100;              "nombre de points de l'échantillon"
taille=60;          "taille des matrices"
max=5;              "randMatrice a des coeffs entre 0 et max"
freq=10;            "fréquence temporelle voulue pour la matrice périodique"
##data1=np.zeros(n);
##data2=np.zeros(n);
##data3=np.zeros(n);
fourier = np.zeros(n);
mp=300
tabfreqmax=[]


traitement_video.detecteur_de_peau(r'/Users/roxanefischer/Desktop/test.mov')
data1=traitement_video.data1
data2=traitement_video.data2
data3=traitement_video.data3


for j in range(mp) :
    for i in range(n) :
        liste1=randMatrice(taille,taille,max);
        liste2=periodMatrice(T,i/n,taille,taille,freq);
        data=liste1+liste2
        data1[i]=traitement_signal.waveTransform2('db2',data);
        data2[i]=traitement_signal.waveTransform2('db4',data);
        data3[i]=traitement_signal.waveTransform2('db7',data);
    fourier = traitement_signal.fourierTransform(data1) + traitement_signal.fourierTransform(data2) + traitement_signal.fourierTransform(data3)
    tabfreqmax.append(np.argmax(fourier[0:int(n/2)]))
time = np.arange(len(tabfreqmax))
plt.plot(time, tabfreqmax)
plt.show()"""








