
import numpy as np
import cv2
import pywt;

##import matplotlib.pyplot as plt
import matplotlib.pyplot as plt;
##from matplotlib import pyplot as plt
from scipy.fftpack import fft;


import detection_visage, scripts_skindetector, skin_detector
##from projet import traitement_signal



getFaceBox = detection_visage.getFaceBox
process = skin_detector.process
logging = skin_detector.logging
display = scripts_skindetector.display



def waveTransform2(wavelet, data):
    res = pywt.dwt2(data, wavelet);
    "effectue la transformée en ondelettes sur data"
    return res[0][0][0];
    "renvoie le premier coefficient"


def fourierTransform(data):
    liste = fft(data);
    "calcule la transformée de fourier (complexe)"
    liste2 = np.abs(liste);
    "calcule le module de chaque coefficient"
    liste2[0] = 0;
    "enlève la composante continue"
    """plt.plot(np.arange(0,n,1),liste2);
    plt.show();"""            "permet d'afficher la transformée de fourier si décommentée"
    return liste2;


def freqselect(listefreq, freqprec,option):
    if(option != 1) :
        return np.argmax(listefreq);
    a = np.argmax(listefreq);
    if(a>freqprec) :
        return freqprec+1;
    if(a==freqprec) :
        print('hello world');
        return freqprec;
    return freqprec-1;


def main(nomDeLaVideo):
    cap = cv2.VideoCapture(nomDeLaVideo);
    "récupère la vidéo"
    m = 300;
    "nombre d'image considérée lors de la transformée de fourier"
    limitationsup = 150;
    "fréquence maximale autorisée"
    limitationinf = 50;
    "fréquence minimale autorisée"
    i = 0;
    "pointeur pour la transformée de fourier"
    tabfreqmax = [];
    "stocke l'indice de la valeur maximale renvoyée par la transformée de fourier"
    data1 = [];
    "stocke les valeurs renvoyées par waveTransform2 pour une première onde"
    data2 = [];
    "deuxième onde"
    data3 = [];
    "troisième onde"
    fps = cap.get(cv2.CAP_PROP_FPS);
    "récupère le nombre d'images par seconde"
    freqinf = int(limitationinf/ (60 / (m / fps)));
    print(freqinf);
    freqsup = min(int(m/2),int(limitationsup/ (60 / (m / fps))));
    print(freqsup);
    "frequence maximale de l'intervale de la transformée de fourier considérée dans le calcul de la fréquence max"
    while (True):
        ret, frame = cap.read();

        "lit la vidéo image par image"
        "arrête la lecture si la vidéo est terminée"
        if ret == True:

            bbox = getFaceBox(frame)
            x = bbox[0]
            y = bbox[1]
            w = bbox[2]
            h = bbox[3]
            frame = np.array(frame);
            if(h!=0 and w != 0) :
                crop_img = frame[y:y + h, x:x + w]
                ##DETECTION PEAU ROXANE
                img_msk = process(crop_img)
                imb_comb = cv2.bitwise_and(crop_img, crop_img, mask=img_msk)  ##sortie visage
                display('img_skn', imb_comb)  ##montre image
                
                b, g, r = cv2.split(frame); "mettre crop_img pour tester avec l'image tronquée"
                "sépare les couleurs de l'image"
                data1.append(waveTransform2('db2', g));
                "rajoute la valeur calculée par waveTransform2 avec la première onde"
                data2.append(waveTransform2('db4', g));
                "deuxième onde"
                data3.append(waveTransform2('db7', g));
                "troisième onde"
                "arrête la lecture si l'utilisateur appuie sur q"
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            break

    n = len(data1);
    "récupère le nombre d'image de la vidéo"
    fourier = fourierTransform(data1[0:m]) + fourierTransform(data2[0:m]) + fourierTransform(data3[0:m]);
    i += 1;
    tabfreqmax.append((freqinf+np.argmax(fourier[freqinf:freqsup])) * int(60 / (m / fps)));
    "tant que le pointeur + le nombre d'image nécessaire ne dépasse pas le nombre d'image total"
    while m + i < n:
        fourier = fourierTransform(data1[i:m + i]) + fourierTransform(data2[i:m + i]) + fourierTransform(
            data3[i:m + i]);
        "somme les transformées de fourier sur les intervalles considérés"
        fourier[0] = 0;
        fourier[1] = 0;
        "évite l'attraction de forts coeffs à faibles fréquences quand l'image est très affectée"
        fourier[2] = 0;
        print(tabfreqmax[-1] / int(60 / (m / fps))-freqinf);
        tabfreqmax.append((freqinf+ freqselect(fourier[freqinf:freqsup], tabfreqmax[-1] / 
                                               int(60 / (m / fps))-freqinf,1)) * int(60 / (m / fps)));
        "calcule et ajoute l'indice du coefficient maximal de la transformée de fourier"
        i = i + 1;
        "met à jour le pointeur"
    time = np.arange(len(tabfreqmax));
    "crée un tableau de 0 à len(tabfreqmax) avec un pas de 1"
    plt.plot(time, tabfreqmax);
    "affiche l'indice du coefficient maximal de la transformée de fourier en fonction de l'image considérée"
    plt.xlabel('Image numéro');
    plt.ylabel('Fréquence estimée');
    axes = plt.gca();
    axes.set_ylim(0, limitationsup);
    plt.title('Fréquence cardiaque estimée pour chaque image');
    plt.show()
    cap.release()
    cv2.destroyAllWindows();
    return fourier

""" ne pas faire attention : stockage en cours
tabfreqmax.append(np.argmax(fourier[0:int(m/2)])* 60 / (m / fps));
vidéo pour les tests 'C:/Users/Alexian/Videos/PSC_test/ma_tete3.MP4' """