

import cv2


(major_ver, minor_ver, subminor_ver) = (cv2.__version__).split('.')
faceCascade = cv2.CascadeClassifier('front.xml')
faceIndex = 0

"""def getFaceBox(image):
    global faceIndex
    # Read the image
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Detect faces in the image
    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE
    )

    print("Found {0} faces!".format(len(faces)))
    if len(faces) == 0:
        return (0, 0, 0, 0)
    correspFace = None
    for f in faces:
        if f[2] > 100:
            cv2.imwrite('./faces/face-' + str(faceIndex) + '.png', image[f[1]:f[1] + f[3], f[0]:f[0] + f[2]])
            correspFace = f
            faceIndex += 1
            break
    if type(correspFace) == type(None):
        return (0, 0, 0, 0)
    proportion = 0.3
    correspFace[0] = correspFace[0]+correspFace[2]*(1-proportion)/2
    correspFace[2] = correspFace[2]*proportion
    correspFace[3] = correspFace[3]*proportion
    return (correspFace[0], correspFace[1], correspFace[2], correspFace[3])"""
def getFaceBox(image):
    global faceIndex
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Detect faces in the image
    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE
    )

    print("Found {0} faces!".format(len(faces)))
    if len(faces) == 0:
        return (0, 0, 0, 0)
    correspFace = None
    for f in faces:
        if f[2] > 100:
            cv2.imwrite('./faces/face-' + str(faceIndex) + '.png', image[f[1]:f[1] + f[3], f[0]:f[0] + f[2]])
            correspFace = f
            faceIndex += 1
            break
    if type(correspFace) == type(None):
        return (0, 0, 0, 0)
    return (correspFace[0], correspFace[1], correspFace[2], correspFace[3])
