
import numpy as np
import pywt;
from scipy.fftpack import fft;
import random


"construit une matrice ligne dont les n valeurs sont un sinus de fréquence freq"
def sinMatrice(freq, n) :
    liste=np.zeros(n);
    for i in range(n) :
        liste[i]=np.sin(2*np.pi*freq*i/n);
    return liste;

"construit une matrice ligne dont les n valeurs sont un cosinus de fréquence freq"
def cosMatrice(freq,n) :
    liste = np.arange(0,n,1);
    liste=liste*(2*np.pi*freq/n);
    liste=np.cos(liste);
    return liste;

"construit une matrice n dont les valeurs sont comprises entre 0 et max (bruit)"
def randMatriceLigne(n,max=1):
    liste=np.zeros(n);
    for i in range (n) :
        liste[i] = random()*max-max/2;
    return liste;

"construit une matrice n,m dont les valeurs sont comprises entre 0 et max (bruit)"
def randMatrice(n,m,max=1):
    liste=np.zeros((n,m));
    for i in range (n):
        for j in range(m) :
            liste[i][j] = random()*max-max/2;
    return liste;

"construit une matrice n,m périodique de période T"
def periodMatrice(T,t,n,m,freq=1,valeur=1):
    liste=np.zeros((n,m));
    for i in range (int(n/T)):
        for j in range(int(m/T)) :
            liste[i*T][j*T]=valeur*np.sin(2*np.pi*freq*t);
    return liste;



"effectue une transformée de Fourier sur une matrice ligne data"
def fourierTransform(data) :
    n=data.size;
    liste = fft(data);
    liste2=np.abs(liste);
    "enlève la composante continue"
    liste2[0]=0;
    """plt.plot(np.arange(0,n,1),liste2);
    plt.show();"""
    return liste2;


def waveTransform(wavelet,T,t,n,m,freq=1,valeur=1,max=1) :
    liste1=randMatrice(n,m,max);
    liste2=periodMatrice(T,t,n,m,freq,valeur);
    "création d'une matrice bruitée"
    liste=liste1+liste2;
    res = pywt.dwt2(liste,wavelet);
    "plt.imshow(res[0]);"
    return res[0][0][0];


def waveTransform2(wavelet,data) :
    res=pywt.dwt2(data,wavelet);
    return res[0][0][0];